Compile paper.tex using PDFLaTeX and BibTeX. Working draft; human authorship, DOI, final rights and ethics review pending. This ZIP contains manuscript inputs, not source media/transcripts.
