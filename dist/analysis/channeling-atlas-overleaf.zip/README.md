# Channeling Atlas working manuscript

Import this ZIP into Overleaf, choose PDFLaTeX and main.tex, then compile.
The unchanged official AAAI 2027 style is at the ZIP root. The source uses
its supported preprint option. This is a working research draft, not a
submitted, accepted, or venue-compliance-certified paper.

Human authorship, institutional ethics determination, construct validation,
and all official checklist answers remain TBD. The model-agent reviews
are not independent human peer review.

Tables and figures are frozen outputs from the linked research repository:
https://github.com/occult-kranti/bashar-index/tree/main/channeling-atlas/research/paper
The package compiles the paper; it does not run collection or inference.
Raw captions and model weights are not included. The manuscript describes
what can be reproduced from the public derived data and what needs source text.

For local compilation, install PDFLaTeX/BibTeX and the dependencies listed
in the repository README. Run pdflatex main, bibtex main, then pdflatex main
twice. Preserve prior releases and rerun the documented analysis pipeline
before editing numerical claims.
