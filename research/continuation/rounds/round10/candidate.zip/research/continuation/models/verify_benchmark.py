#!/usr/bin/env python3
"""Audit executed output/source splits and deterministic metric bookkeeping."""
import collections,hashlib,json,math,pathlib,re
HERE=pathlib.Path(__file__).resolve().parent
def words(s):return collections.Counter(re.findall(r'[a-z0-9]+',s.lower()))
def overlap(a,b):
 x,y=words(a),words(b);return 2*sum((x&y).values())/(sum(x.values())+sum(y.values())) if x and y else 0.
def main():
 split=json.loads((HERE/'split.json').read_text());result=json.loads((HERE/'benchmark-results.json').read_text());rr=json.loads((HERE/'predictions.json').read_text())['records'];training=json.loads((HERE/'training-receipt.json').read_text());checks=0
 def check(ok,message):
  nonlocal checks
  checks+=1
  if not ok:raise AssertionError(message)
 train={x['id']:x for x in split['train']};test={x['id']:x for x in split['test']};controls={x['id']:x for x in split['controlRecords']}
 check(not set(train)&set(test),'Disjoint example IDs')
 check(not {x['videoId'] for x in train.values()}&{x['videoId'] for x in test.values()},'Disjoint upload IDs')
 check(not {x['sourceGroupId'] for x in train.values()}&{x['sourceGroupId'] for x in test.values()},'Disjoint source-proxy groups')
 check(len(rr)==50,'Five arms each execute eight questions and two controls')
 check(training['status']=='completed' and training['examples']==48 and training['microsteps']==48 and training['optimizerSteps']==12,'Actual bounded CPU LoRA steps completed')
 check(len(training['losses'])==48 and all(math.isfinite(x['loss']) for x in training['losses']),'Finite actual training losses')
 check(0<training['trainableParameters']<training['totalParameters']*.01,'Small trainable LoRA subset')
 for p in rr:
  check(p['id'] in test or p['id'] in controls,'Predicted heldout/control IDs only')
  check(all(d['candidateId'] in train for d in p['retrievedEvidence']),'RAG evidence drawn from training only')
  check(not {d['candidateId'] for d in p['retrievedEvidence']}&set(test),'No heldout answer in evidence')
  check(p['seconds']>=0 and p['generatedTokens']<=40,'Recorded timing and generation bounds')
  if not p['control']:check(abs(overlap(p['output'],p['referenceAnswerGist'])-p['tokenF1ToHeldoutDigest'])<.000001,'Independently recomputed token F1')
 for arm in result['arms']:
  rows=[x for x in rr if x['arm']==arm['id']];qa=[x for x in rows if not x['control']];cc=[x for x in rows if x['control']]
  check(len(qa)==8 and len(cc)==2,'Every arm has the same evaluation denominator')
  check(abs(sum(x['tokenF1ToHeldoutDigest'] for x in qa)/8-arm['meanTokenF1'])<.000001,'Mean token overlap agrees')
  check(abs(sum(x['seconds'] for x in rows)/10-arm['meanSeconds'])<.000001,'Mean response timing agrees')
  check(sum(x['abstained'] for x in cc)/2==arm['abstentionRateOnControls'],'Control abstention agrees')
 source_sha=hashlib.sha256((HERE/'run_benchmark.py').read_bytes()).hexdigest()
 from transformers import AutoTokenizer
 from run_benchmark import CACHE,SYSTEM
 tokenizer=AutoTokenizer.from_pretrained(str(CACHE),local_files_only=True,trust_remote_code=False)
 truncations=[]
 for row,loss in zip(split['train'],training['losses']):
  prompt=tokenizer.apply_chat_template([{'role':'system','content':SYSTEM},{'role':'user','content':'Question: '+row['question']}],tokenize=False,add_generation_prompt=True)
  prefix=tokenizer(prompt,add_special_tokens=False)['input_ids'];target=tokenizer('The digest states: '+row['answerGist']+tokenizer.eos_token,add_special_tokens=False)['input_ids']
  used=max(0,min(len(target),192-len(prefix)))
  check(loss['tokens']==min(192,len(prefix)+len(target)),'Recorded training cap matches exact prompt/target tokenization')
  truncations.append({'candidateId':row['id'],'prefixTokens':len(prefix),'answerTokensAvailable':len(target),'answerTokensUsed':used,'answerTruncated':used<len(target)})
 caps={a['id']:{'generationCapHits':sum(p['generatedTokens']==40 for p in rr if p['arm']==a['id']),
                 'promptTruncations':sum(p.get('promptTruncated',False) for p in rr if p['arm']==a['id'])} for a in result['arms']}
 length={'trainingAnswerTruncatedCount':sum(x['answerTruncated'] for x in truncations),'trainingRecords':truncations,'generationCapsByArm':caps,
         'interpretation':'System requests under 40 words, but generation is limited to 40 tokens; cap hits and training truncation can lower lexical overlap. Neither is an accuracy measure.'}
 (HERE/'length-audit.json').write_text(json.dumps(length,indent=2)+'\n')
 receipt={'status':'PASS','checks':checks,'runSourceSha256':source_sha,'predictionsSha256':hashlib.sha256((HERE/'predictions.json').read_bytes()).hexdigest(),
          'benchmarkResultsSha256':hashlib.sha256((HERE/'benchmark-results.json').read_bytes()).hexdigest(),'trainingReceiptSha256':hashlib.sha256((HERE/'training-receipt.json').read_bytes()).hexdigest(),
          'trainingAnswerTruncatedCount':length['trainingAnswerTruncatedCount'],'generationCapsByArm':caps,'factualAccuracyValidated':False,'humanGroundTruth':False}
 (HERE/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
