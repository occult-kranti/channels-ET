# Channeling digest CPU LoRA pilot

This is a 48-example, one-epoch feasibility adapter, not a validated expert model.
Base model: Qwen/Qwen2.5-0.5B-Instruct at revision `7ae557604adf67be50417f59c2c2f167def9a775` (Apache-2.0).
The archive targets are pre-existing AI-generated Darryl Anka/Bashar-context question/answer-gist paraphrases. They are not transcript turns, verified speaker labels or factual ground truth.

Load the exact base with Transformers 4.51.3, then use PEFT 0.15.2 `PeftModel.from_pretrained(base, adapter_directory)`. CPU training used Torch 2.6.0+cpu, rank4, alpha8, q/v projection targets, sequence cap192,48 microsteps/12 optimizer steps. The bundle excludes all base-model weights and raw speech.

Do not infer medical/scientific validity, speaker authenticity or extraterrestrial origin from a generated answer. Tiny-pilot lexical metrics do not establish general-domain quality. See the companion split, predictions and benchmark receipts.
