# Local model and retrieval experiments

The first executed experiment is a small **CPU feasibility and reconstruction
pilot**, using official Qwen2.5-0.5B-Instruct revision
`7ae557604adf67be50417f59c2c2f167def9a775`, Apache-2.0. It is not a state-of-the-art
claim. `current-family-check.json` records newer official Qwen3/Qwen3.5
repositories separately; only a completed `current-family-smoke.json` establishes
that the newer model actually ran locally.

## What ran

`benchmark-results.json`, `predictions.json` and `training-receipt.json` document
five arms on the same eight heldout questions and two unsupported controls:

1. Train-only TF-IDF retrieval returning its highest-ranked answer gist.
2. The base local model without retrieved excerpts.
3. The base local model with at most two train-only evidence excerpts.
4. The CPU LoRA adapter without retrieved excerpts.
5. The CPU LoRA adapter with the same retrieval method.

Forty-eight pre-existing AI-digest paraphrases trained a rank-4 q/v-projection
adapter for one epoch: 48 microsteps, gradient accumulation four, 12 AdamW steps,
192-token sequence cap and learning rate0.0002. The actual training took65.04
seconds on two Torch CPU threads. It trained270,336 of494,303,104 parameters.
No GPU was available, and no CPU/GPU throughput comparison was fabricated.

`split.json` preserves all48 training and eight heldout candidate/source IDs.
Uploads are quarantined into55 conservative proxy source families using exact
question repetition, high question similarity or multiple recurrent questions.
Training covers47 families and evaluation eight disjoint families. These proxy
families are not verified original sessions and cannot eliminate unknown reuse
or unknown base-model pretraining contamination.

RAG fits its TF-IDF vocabulary and index on the48 training examples only.
It retrieves at most two excerpts with query cosine at least0.10. The eight
heldout answers are never included as evidence. Five heldout questions have
some above-threshold evidence; three have none. A retrieved passage is not
assumed to answer the question. The lexical baseline itself returns an unrelated
training gist on one unsupported control, demonstrating that retrieval presence
is not answer support.

## Interpretation and metrics

References are inherited **AI-generated digest answer gists from one
Darryl Anka/Bashar context**, not human ground truth, actual transcript turns or
verified factual answers. Multiset alphanumeric token F1 measures reconstruction
overlap only. Eight examples cannot establish a reliable model ranking. The
LoRA closed-book overlap increased in this pilot, but the same adapter invented
an unsupported studio temperature of23°C on a control. This is a concrete
negative example of why overlap is not factual reliability.

The initial abstention metric tests exact `INSUFFICIENT_EVIDENCE` marker
compliance. Plain `Insufficient evidence.` receives zero under that strict
parser. Do not describe the initial metric as semantic refusal accuracy.
Source-label membership means a generated `[D1]` or `[D2]` matches a supplied
label, not that any assertion is entailed. Generation supplied no valid source
labels in the initial RAG heldout outputs; most of those outputs refused.

Latency includes query retrieval when used, prompt tokenization and generation,
excluding one-time weight loading and index fitting. It describes this shared
CPU process and short prompts, not a hardware ranking. The instruction asks for
under40 words, but the actual hard generation cap is40 tokens. `length-audit.json`
records zero training-answer truncations and zero inference-prompt truncations;
five LoRA-closed and one LoRA-RAG outputs reached the40-token generation cap.

`verify_benchmark.py` independently recomputes bookkeeping from saved outputs,
checks train/evaluation isolation and evidence membership, and records lengths.
It does not validate factual truth or annotation constructs. The initial
verification contains315 checks. Generated outputs and negative results remain
inspectable rather than being silently corrected.

Round11 adds `posthoc-diagnostics.json` and a12-excerpt local content-label
experiment. Nine label records parse, three fail, all nine primary themes choose
`contact_forecast`, and none of the nine parsed support spans matches the source
exactly. These are model/prompt failures, not corpus theme findings. Conditional
label/regex concordance is5/9, without human accuracy labels. The inherited
`depend\w*` pattern can match `dependency` without a logical condition.
Four answer-present training-source citation controls also omit the requested
source label. Their answers are deliberately supplied, so those controls are
excluded from heldout/generalization metrics. A separate post-hoc refusal-phrase
parser recognizes plain `Insufficient evidence.`; it does not replace the strict
marker metric.

Official Qwen3.5-0.8B revision `2fc06364715b967f1860aea9cf38778875588b17`
actually ran in the modern CPU environment:23 generated tokens,3.881313s
generation time,5,593,472KiB peak process RSS, requested provenance JSON produced.
This single text-only schema probe explicitly provides its target provenance
facts. It does not test images, video, speech, factual accuracy or domain quality.

## Software, downloads and artifacts

Baseline environment: `/workspace/channels-et-model-venv`, Torch2.6.0+cpu,
Transformers4.51.3, PEFT0.15.2, Accelerate1.6.0. Full package versions are in
`cpu-environment-freeze.txt`. The separate modern inference environment uses
Transformers5.20.2 and explicit read-only links to Torch dependencies from the
baseline environment; it does not expose the old Transformers or PEFT package.

Model caches remain outside Git under `/workspace/channels-et-model-cache`.
`download_model.py` fetches a pinned official Hub revision, verifies safetensors
against official LFS SHA-256 values and smaller files against official Git blob
hashes. No TLS verification, signatures or hashes were disabled. The first
premature tokenizer attempt and its correction are disclosed in
`setup-events.json`; no predictions or training occurred in that failed attempt.

The actual pilot adapter is released as `qwen-digest-lora-pilot.zip` with its
weights, config, base-model revision, Apache license and training manifest.
`adapter-package.json` records its hashes. The archive is about1MB and excludes
all full base-model weights and raw captions. It is an experimental adapter,
not a validated specialist or source of medical/scientific advice.
The package also includes48 digest source IDs/hash/pointers and QA/split/protocol
hashes, with a NOTICE distinguishing the Apache base/adapter distribution from
inherited MIT digest data. Original recording rights remain separate.

Reproduction in the baseline environment:

```sh
python research/continuation/models/download_model.py
python research/continuation/models/run_benchmark.py
python research/continuation/models/verify_benchmark.py
python research/continuation/models/package_adapter.py
```

For source-only verification without the model cache or Transformers:

```sh
python research/continuation/models/verify_benchmark.py --offline
python research/continuation/models/verify_round11.py
```

The offline verifier checks saved predictions, metrics and adapter ZIP/source
hashes, while explicitly marking tokenizer recomputation as skipped. Retained
length evidence is not relabeled as a new tokenization or neural-inference run.

The benchmark command **reruns inference and CPU training and overwrites its
outputs**. Preserve reviewed round snapshots before rerunning. Newer-family
downloads require their own explicit model/revision/cache/manifest arguments;
their smoke test runs in the modern environment. Installed/downloaded software
without a completed run receipt is not empirical model evidence.
