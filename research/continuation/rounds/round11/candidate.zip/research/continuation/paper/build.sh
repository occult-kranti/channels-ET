#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export SOURCE_DATE_EPOCH=1792713600
export FORCE_SOURCE_DATE=1
export MPLCONFIGDIR="${MPLCONFIGDIR:-/workspace/channels-et-tex/matplotlib}"
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-/workspace/channels-et-tex/cache}"
if [ ! -f /workspace/channels-et-tex/texmf/tex/latex/newtx/newtxtext.sty ]; then
  python3 scripts/setup_tex.py
fi
export TEXMFHOME=/workspace/channels-et-tex/texmf
export TEXMFVAR=/workspace/channels-et-tex/var
export TEXMFCONFIG=/workspace/channels-et-tex/config
export TEXINPUTS="$(pwd)/vendor//:${TEXINPUTS:-}"
export BSTINPUTS="$(pwd)/vendor//:${BSTINPUTS:-}"
python3 scripts/evidence_flow.py
python3 scripts/generate.py
mkdir -p build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build main.tex > build/pass1.log
bibtex build/main > build/bibtex.log
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build main.tex > build/pass2.log
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build main.tex > build/pass3.log
cp build/main.pdf channels-et-paper.pdf
python3 scripts/package.py
