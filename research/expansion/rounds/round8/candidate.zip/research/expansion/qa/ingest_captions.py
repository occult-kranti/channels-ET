#!/usr/bin/env python3
"""Experimental local question-window extractor for authorized caption segments.

Raw candidate windows must remain outside Git. A public manifest contains only
hashes, time boundaries and regex category indicators. This CLI has been tested
with synthetic fixtures only; no empirical caption extraction is implied.
"""
from __future__ import annotations
import argparse, hashlib, json, pathlib
from build_qa import classify, THEMES, MODALITY

def inside_git(path):
    path = path.resolve()
    # Managed sandboxes mount empty reserved .git directories at /tmp and
    # /workspace. They are not repository metadata; do not confuse them with a
    # checkout. Recognize real directory HEADs and linked-worktree gitdir files.
    for parent in (path, *path.parents):
        meta = parent / ".git"
        if meta.is_dir() and (meta / "HEAD").is_file(): return True
        if meta.is_file() and meta.read_text().strip().startswith("gitdir:"): return True
    return False

def extract(document):
    vid = document["video_id"]
    segments = document["segments"]
    candidates = []
    for i, s in enumerate(segments):
        if "?" not in s.get("text", ""):
            continue
        if not isinstance(s.get("start"), (int, float)) or s["start"] < 0:
            raise ValueError("Question candidate requires a nonnegative numeric segment start")
        following = []
        for j in range(i + 1, min(len(segments), i + 13)):
            next_segment = segments[j]
            if "?" in next_segment.get("text", "") or next_segment["start"] - s["start"] > 120:
                break
            following.append(next_segment)
        if not following:
            continue
        candidates.append({"id": f"caption-window-{vid}-{i:05d}", "video_id": vid,
                           "question_candidate": s["text"],
                           "answer_window_candidate": " ".join(x["text"] for x in following),
                           "question_segment_index": i, "question_start_seconds": s["start"],
                           "answer_start_seconds": following[0]["start"],
                           "answer_end_seconds": following[-1]["start"] + following[-1].get("duration", 0),
                           "speaker_verified": False, "turn_boundary_verified": False,
                           "evidence_type": "punctuation_based_caption_window_candidate",
                           "human_reviewed": False})
    return candidates

def run(input_path, output_path, manifest_path):
    if inside_git(output_path):
        raise ValueError("Raw question/answer windows must be written outside every Git checkout")
    if output_path.resolve() == manifest_path.resolve():
        raise ValueError("Manifest and raw output require different paths")
    if output_path.exists() or manifest_path.exists():
        raise ValueError("Choose fresh output paths; existing files are never overwritten")
    document = json.loads(input_path.read_text())
    rows = extract(document)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps({"status": "unvalidated_candidates", "records": rows}, ensure_ascii=False, indent=2))
    public = [{"id": r["id"], "video_id": r["video_id"], "question_start_seconds": r["question_start_seconds"],
               "answer_start_seconds": r["answer_start_seconds"], "answer_end_seconds": r["answer_end_seconds"],
               "question_sha256": hashlib.sha256(r["question_candidate"].encode()).hexdigest(),
               "answer_window_sha256": hashlib.sha256(r["answer_window_candidate"].encode()).hexdigest(),
               "question_themes": classify(r["question_candidate"], THEMES),
               "answer_themes": classify(r["answer_window_candidate"], THEMES),
               "answer_modality_markers": classify(r["answer_window_candidate"], MODALITY),
               "speaker_verified": False, "turn_boundary_verified": False, "human_reviewed": False}
              for r in rows]
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps({"source_sha256": hashlib.sha256(input_path.read_bytes()).hexdigest(),
                                        "method": "Question-mark-bearing segment followed by at most 12 segments/120 seconds until the next question mark; no diarization",
                                        "status": "unvalidated_candidates", "records": public}, indent=2))
    return public

if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("input", type=pathlib.Path);p.add_argument("raw_output", type=pathlib.Path)
    p.add_argument("public_manifest", type=pathlib.Path)
    a = p.parse_args()
    print(json.dumps({"candidate_windows": len(run(a.input, a.raw_output, a.public_manifest)), "speaker_validated": False}))
