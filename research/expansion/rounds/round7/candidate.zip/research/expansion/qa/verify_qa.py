#!/usr/bin/env python3
"""Independent source-to-candidate and database-integrity checks."""
from __future__ import annotations
import collections, hashlib, json, pathlib, sqlite3, tempfile
from ingest_captions import extract, run

HERE = pathlib.Path(__file__).resolve().parent
REPO = HERE.parents[3]
def main():
    rows = json.loads((HERE / "qa-candidates.json").read_text())["records"]
    summary = json.loads((HERE / "summary.json").read_text())
    lookup = {r["id"]: r for r in rows}
    checks = 0
    def check(ok, msg):
        nonlocal checks
        checks += 1
        if not ok: raise AssertionError(msg)
    expected = sum(len(json.loads(p.read_text()).get("qa_topics", [])) for p in (REPO / "data/digests").glob("*.json"))
    check(len(rows) == expected, "Every original qa_topics entry must survive once")
    check(len(rows) == len(lookup), "Unique candidate primary keys")
    for r in rows:
        path = REPO / r["sourcePath"]
        source = json.loads(path.read_text())
        qindex = int(r["sourcePointer"].split("/")[-1])
        q = source["qa_topics"][qindex]
        check(hashlib.sha256(path.read_bytes()).hexdigest() == r["sourceSha256"], r["id"] + " source hash")
        check(r["question"] == q["question"].strip() and r["answerGist"] == q["answer_gist"].strip(), r["id"] + " exact digest pointer")
        check(r["videoId"] == source["video_id"] and r["videoId"] in r["sourceUrl"], r["id"] + " video/url identity")
        check(r["timestampSeconds"] is None and not r["speakerVerified"] and r["entityIsSpeaker"] is None, "No inferred speaker/timestamp")
    db = sqlite3.connect(HERE / "qa-candidates.sqlite")
    check(db.execute("PRAGMA integrity_check").fetchone()[0] == "ok", "SQLite integrity")
    check(not db.execute("PRAGMA foreign_key_check").fetchall(), "SQLite foreign keys")
    check(db.execute("SELECT count(*) FROM qa_candidates").fetchone()[0] == len(rows), "SQLite matches JSON candidates")
    check(db.execute("SELECT count(*) FROM practitioner_coverage").fetchone()[0] == len(summary["practitionerCoverage"]), "All practitioner candidates retained")
    check(sum(p["qaCandidateCount"] for p in summary["practitionerCoverage"]) == len(rows), "Practitioner exact-name joins reconcile")
    check(summary["coverage"]["crossPractitionerComparisonAvailable"] is False, "Single-practitioner candidate frame")
    check(len([r for r in rows if r["publisherId"] is None]) == summary["coverage"]["candidatesWithoutResolvedPublisherId"], "Unknown publisher records retained")
    for pair in json.loads((HERE / "question-pairs.json").read_text())["records"]:
        left,right=lookup[pair["leftId"]],lookup[pair["rightId"]]
        check(left["videoId"] != right["videoId"] and pair["questionCosine"] >= .4, "Distinct-upload candidate threshold")
        check(pair["answerAgreement"] == "not_assessed" and pair["originalSessionIndependence"] == "unknown", "No agreement/independence inference")
        if left["publisherId"] is None or right["publisherId"] is None:
            check(pair["samePublisher"] is None, "Unknown publishers cannot become matched accounts")
    review=json.loads((HERE/"close-reading.json").read_text())
    check(len(review["records"])==20 and len({r["candidateId"] for r in review["records"]})==20,"Twenty distinct model-read candidates")
    check(all(r["candidateId"] in lookup for r in review["records"]),"Close-reading rows resolve")
    # Synthetic fixture exercises punctuation segmentation, bounds and release separation.
    synthetic={"video_id":"SYNTHETIC01","segments":[{"text":"What might happen?","start":1,"duration":2},
       {"text":"A possible answer window.","start":4,"duration":3},
       {"text":"Second question?","start":8,"duration":2},
       {"text":"Next answer.","start":11,"duration":2}]}
    extracted=extract(synthetic)
    check(len(extracted)==2 and extracted[0]["answer_end_seconds"]==7,"Caption candidate windows stop at next question")
    with tempfile.TemporaryDirectory(prefix="qa-fixture-") as td:
        temp=pathlib.Path(td); inp=temp/"synthetic.json";inp.write_text(json.dumps(synthetic))
        pub=run(inp,temp/"raw.json",temp/"manifest.json")
        check("question_candidate" not in pub[0] and "answer_window_candidate" not in pub[0],"Public caption manifest excludes source text")
        try:run(inp,REPO/"forbidden-raw.json",temp/"manifest2.json")
        except ValueError:check(True,"Raw caption output to Git is rejected")
        else:check(False,"Raw caption output leaked into Git")
    receipt={"status":"PASS","checks":checks,"candidateCount":len(rows),"sourceDigests":75,
             "videosWithQACandidates":len({r["videoId"] for r in rows}),
             "sourceHashPointersVerified":len(rows),"sqliteIntegrity":"ok",
             "captionWindowTests":"synthetic fixture only; no real raw captions used",
             "summarySha256":hashlib.sha256((HERE/"summary.json").read_bytes()).hexdigest()}
    (HERE/"verification.json").write_text(json.dumps(receipt,indent=2)+"\n")
    print(json.dumps(receipt,indent=2))
if __name__=="__main__":main()
